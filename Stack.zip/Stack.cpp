/* 
 * Stack.cpp
 *
 * Description: Implementation of an int sequence with push/pop ...
 * Class Invariant: ... in a LIFO order
 *
 * Author:
 * Date:
 */

#include "Stack.h"
#include <iostream>

using namespace std;


// Description: Constructor
Stack::Stack() {
    elementCount = 0;
 
}


// Description: Destructor
Stack::~Stack()
{
}


// Description: Returns true if Stack empty.
bool Stack::isEmpty() const {
    return elementCount == 0;
}

void Stack::print() {

    cout << "------------------" << endl;
    
    for (int i = 0; i < elementCount; i++) {

       cout << arr[i] << endl;

    }


}



// Description: Insert element x to the top of Stack.
void Stack::push(int x) {
    arr[elementCount++] = x;
} 

// Description: Remove and return element at the top of Stack.
int Stack::pop() {

    return arr[--elementCount];

    arr[elementCount + 1] = NULL;
} 

// Description: Removes and returns the max element.
//              In case of duplicated max, take the one closest to the top.
// Precondition: Stack nonempty
// Postcondition: Order of remaining elements is preserved
int Stack::removeMax() {
    int maxElement = 0;
    int temp = 0;
    int e = 0;
    
    for (int i = 0; i < elementCount; i++) {

        temp = arr[i];

        if (temp >= maxElement) {

            maxElement = arr[i];
            e = i;

        }

    }

    for (int r = e; r < elementCount ; r++) {

        arr[e] = arr[e + 1];

    }

    arr[elementCount] = NULL;

    elementCount -= 1;


    return maxElement;
} 


