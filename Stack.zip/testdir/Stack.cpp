/* 
 * Stack.cpp
 *
 * Description: Implementation of an int sequence with push/pop ...
 * Class Invariant: ... in a LIFO order
 *
 * Author:
 * Date:
 */

#include "Stack.h"


// Description: Constructor
Stack::Stack() {
    elementCount = 0;
}

// Description: Returns true if Stack empty.
bool Stack::isEmpty() const {
    return elementCount == 0;
} 

// Description: Insert element x to the top of Stack.
void Stack::push(int x) {
    arr[elementCount++] = x;
} 

// Description: Remove and return element at the top of Stack.
int Stack::pop() {
    return arr[--elementCount];
} 

// Description: Removes and returns the max element.
//              In case of duplicated max, take the one closest to the top.
// Precondition: Stack nonempty
// Postcondition: Order of remaining elements is preserved
int Stack::removeMax() {
    int maxElement = 0;

    // Put your code here!

    return maxElement;
} 


